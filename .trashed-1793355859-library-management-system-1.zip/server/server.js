const express = require("express");
const cors = require("cors");
const path = require("path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
require("dotenv").config();
const db = require("./config/database");
const auth = require("./middleware/auth");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "../frontend")));

const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);

app.post("/api/auth/login", asyncRoute(async (req,res)=>{
  const {email,password}=req.body;
  const [rows]=await db.query("SELECT * FROM users WHERE email=?", [email]);
  if(!rows.length || !(await bcrypt.compare(password, rows[0].password)))
    return res.status(401).json({error:"Invalid email or password"});
  const user=rows[0];
  const token=jwt.sign({id:user.id,name:user.name,email:user.email,role:user.role},process.env.JWT_SECRET,{expiresIn:"8h"});
  res.json({token,user:{id:user.id,name:user.name,email:user.email,role:user.role}});
}));

app.get("/api/dashboard", auth, asyncRoute(async (req,res)=>{
  const [[books]]=await db.query("SELECT COUNT(*) total FROM books");
  const [[members]]=await db.query("SELECT COUNT(*) total FROM members");
  const [[issued]]=await db.query("SELECT COUNT(*) total FROM issues WHERE status='issued'");
  const [[overdue]]=await db.query("SELECT COUNT(*) total FROM issues WHERE status='issued' AND due_date<CURDATE()");
  res.json({books:books.total,members:members.total,issued:issued.total,overdue:overdue.total});
}));

app.get("/api/books", auth, asyncRoute(async (req,res)=>{
  const q=`%${req.query.q||""}%`;
  const [rows]=await db.query(
    "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ? OR category LIKE ? ORDER BY id DESC",
    [q,q,q,q]
  );
  res.json(rows);
}));
app.post("/api/books", auth, asyncRoute(async(req,res)=>{
  const b=req.body, total=Number(b.total_copies||1);
  const [r]=await db.query(
    "INSERT INTO books(isbn,title,author,category,publisher,year,total_copies,available_copies) VALUES(?,?,?,?,?,?,?,?)",
    [b.isbn||null,b.title,b.author,b.category||null,b.publisher||null,b.year||null,total,total]
  );
  res.status(201).json({id:r.insertId});
}));
app.put("/api/books/:id", auth, asyncRoute(async(req,res)=>{
  const b=req.body;
  const [old]=await db.query("SELECT total_copies,available_copies FROM books WHERE id=?",[req.params.id]);
  if(!old.length) return res.status(404).json({error:"Book not found"});
  const delta=Number(b.total_copies)-Number(old[0].total_copies);
  const available=Math.max(0,Number(old[0].available_copies)+delta);
  await db.query("UPDATE books SET isbn=?,title=?,author=?,category=?,publisher=?,year=?,total_copies=?,available_copies=? WHERE id=?",
    [b.isbn||null,b.title,b.author,b.category||null,b.publisher||null,b.year||null,b.total_copies,available,req.params.id]);
  res.json({message:"Book updated"});
}));
app.delete("/api/books/:id", auth, asyncRoute(async(req,res)=>{
  const [[x]]=await db.query("SELECT COUNT(*) c FROM issues WHERE book_id=?",[req.params.id]);
  if(x.c) return res.status(400).json({error:"Cannot delete a book with issue history"});
  await db.query("DELETE FROM books WHERE id=?",[req.params.id]); res.json({message:"Deleted"});
}));

app.get("/api/members", auth, asyncRoute(async(req,res)=>{
  const q=`%${req.query.q||""}%`;
  const [rows]=await db.query("SELECT * FROM members WHERE name LIKE ? OR member_code LIKE ? OR email LIKE ? OR phone LIKE ? ORDER BY id DESC",[q,q,q,q]);
  res.json(rows);
}));
app.post("/api/members", auth, asyncRoute(async(req,res)=>{
  const m=req.body;
  const [r]=await db.query("INSERT INTO members(member_code,name,email,phone,address) VALUES(?,?,?,?,?)",[m.member_code,m.name,m.email||null,m.phone||null,m.address||null]);
  res.status(201).json({id:r.insertId});
}));
app.put("/api/members/:id", auth, asyncRoute(async(req,res)=>{
  const m=req.body;
  await db.query("UPDATE members SET member_code=?,name=?,email=?,phone=?,address=? WHERE id=?",[m.member_code,m.name,m.email||null,m.phone||null,m.address||null,req.params.id]);
  res.json({message:"Member updated"});
}));
app.delete("/api/members/:id", auth, asyncRoute(async(req,res)=>{
  const [[x]]=await db.query("SELECT COUNT(*) c FROM issues WHERE member_id=?",[req.params.id]);
  if(x.c) return res.status(400).json({error:"Cannot delete a member with issue history"});
  await db.query("DELETE FROM members WHERE id=?",[req.params.id]); res.json({message:"Deleted"});
}));

app.get("/api/issues", auth, asyncRoute(async(req,res)=>{
  const [rows]=await db.query(`SELECT i.*,b.title book_title,m.name member_name,m.member_code,
    CASE WHEN i.status='issued' AND i.due_date<CURDATE() THEN DATEDIFF(CURDATE(),i.due_date) ELSE 0 END overdue_days
    FROM issues i JOIN books b ON b.id=i.book_id JOIN members m ON m.id=i.member_id ORDER BY i.id DESC`);
  res.json(rows);
}));
app.post("/api/issues", auth, asyncRoute(async(req,res)=>{
  const {book_id,member_id,due_date}=req.body;
  const conn=await db.getConnection();
  try {
    await conn.beginTransaction();
    const [b]=await conn.query("SELECT available_copies FROM books WHERE id=? FOR UPDATE",[book_id]);
    if(!b.length || b[0].available_copies<1) throw new Error("Book is not available");
    await conn.query("INSERT INTO issues(book_id,member_id,issued_by,issue_date,due_date) VALUES(?,?,?,CURDATE(),?)",[book_id,member_id,req.user.id,due_date]);
    await conn.query("UPDATE books SET available_copies=available_copies-1 WHERE id=?",[book_id]);
    await conn.commit(); res.status(201).json({message:"Book issued"});
  } catch(e){await conn.rollback(); res.status(400).json({error:e.message});} finally{conn.release();}
}));
app.post("/api/issues/:id/return", auth, asyncRoute(async(req,res)=>{
  const conn=await db.getConnection();
  try {
    await conn.beginTransaction();
    const [rows]=await conn.query("SELECT * FROM issues WHERE id=? AND status='issued' FOR UPDATE",[req.params.id]);
    if(!rows.length) throw new Error("Active issue not found");
    const i=rows[0];
    const [[d]]=await conn.query("SELECT GREATEST(DATEDIFF(CURDATE(),due_date),0) overdue_days FROM issues WHERE id=?",[i.id]);
    const fine=d.overdue_days*Number(process.env.FINE_PER_DAY||5);
    await conn.query("UPDATE issues SET status='returned',return_date=CURDATE(),fine=? WHERE id=?",[fine,i.id]);
    await conn.query("UPDATE books SET available_copies=available_copies+1 WHERE id=?",[i.book_id]);
    await conn.commit(); res.json({message:"Book returned",fine});
  } catch(e){await conn.rollback(); res.status(400).json({error:e.message});} finally{conn.release();}
}));

app.get("/api/reports", auth, asyncRoute(async(req,res)=>{
  const [rows]=await db.query(`SELECT i.id,b.title,m.name member_name,i.issue_date,i.due_date,i.return_date,i.fine,i.status
    FROM issues i JOIN books b ON b.id=i.book_id JOIN members m ON m.id=i.member_id ORDER BY i.id DESC`);
  res.json(rows);
}));

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"../frontend/index.html")));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:"Server error"});});

const PORT=process.env.PORT||3000;
app.listen(PORT,()=>console.log(`Library system running at http://localhost:${PORT}`));