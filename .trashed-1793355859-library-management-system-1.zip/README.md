# Library Management System

## Requirements
- Node.js 18+
- MySQL 8+

## Setup

1. Create the database:
   - Open MySQL Workbench or the MySQL CLI.
   - Run `database/library.sql`.

2. Configure environment:
   - Copy `.env.example` to `.env`.
   - Set your MySQL password and a strong JWT secret.

3. Install dependencies:
   ```bash
   npm install
   ```

4. Start:
   ```bash
   npm start
   ```

5. Open:
   http://localhost:3000

## Default login
Email: admin@library.com
Password: admin123

## Main features
- Admin/staff authentication
- Dashboard statistics
- Book CRUD and search
- Member CRUD and search
- Issue and return workflow
- Automatic overdue fine calculation
- Issue history and printable reports

For production use, change the demo admin password, JWT secret, database credentials, and add stronger validation/rate limiting.
